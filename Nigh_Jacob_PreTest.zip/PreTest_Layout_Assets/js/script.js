/* Jacob Nigh
 * March 3, 2015
 * PWA1
 */

/* alert('Welcome to my online store!');

var item = prompt("What is the cost of your item?");
while(isNaN(item) || item === "")
{
    item = prompt("Im sorry, Please enter the cost of your item.");
}
var discount = prompt("What is the discount percent of your item?");
while (isNaN(discount) || discount === "" || discount < 0 || discount >= 101)
{
    discount = prompt("Im sorry, Please enter the discount percent of your item.");
}
function finalCost(cost, disc)
{
   total = cost * (disc / 100);
   total2 = cost - total;
   return total2;
}

var results = finalCost(item, discount);
console.log("The cost of your item with the discount is " + results + " dollars.");
alert("The total cost of your item with the discount is " + results + " dollars.");
*/